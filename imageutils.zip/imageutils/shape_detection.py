import math
import cv2
import numpy as np
# import matplotlib.pyplot as plt
from typing import Tuple
from copy import deepcopy
from PIL import Image, ImageDraw
from .image_crop import OneCrop


def rotated_coordinates(angle, rectboxs, pointx, pointy):
    """
    vertex coordinates after rotation along the angle
    :param angle: rotation angle
    :param rectboxs: vertex coordinates in the form of [(x0,y0),(x1,y1),(x2,y2),(x3,y3)]
    :param pointx: abscissa of rotation center
    :param pointy: ordinate of rotation center
    :return: vertex coordinates after rotation, in the same form of rectboxs
    """
    output = []

    def aiticlock_rotate(angle, valuex, valuey, pointx, pointy):
        angle = (angle / 180) * math.pi
        valuex = np.array(valuex)
        valuey = np.array(valuey)
        rotatex = (valuex - pointx) * math.cos(angle) - (valuey - pointy) * math.sin(angle) + pointx
        rotatey = (valuex - pointx) * math.sin(angle) + (valuey - pointy) * math.cos(angle) + pointy
        return rotatex, rotatey

    def clock_rotate(angle, valuex, valuey, pointx, pointy):
        angle = (angle / 180) * math.pi
        valuex = np.array(valuex)
        valuey = np.array(valuey)
        rotatex = (valuex - pointx) * math.cos(angle) + (valuey - pointy) * math.sin(angle) + pointx
        rotatey = (valuey - pointy) * math.cos(angle) - (valuex - pointx) * math.sin(angle) + pointy
        return rotatex, rotatey

    for rectbox in rectboxs:
        if angle > 0:
            output.append(clock_rotate(angle, rectbox[0], rectbox[1], pointx, pointy))
        else:
            output.append(aiticlock_rotate(-angle, rectbox[0], rectbox[1], pointx, pointy))
    return output

def xy_from_panel2img(x, y, one_img_para):
    x1, y1 = x + np.min(one_img_para[0][:, 0]), \
           y + np.min(one_img_para[0][:, 1])
    img_x, img_y = np.int0(rotated_coordinates(one_img_para[2], [(x1, y1)],
                                               one_img_para[1][0], one_img_para[1][1])[0])
    img_x, img_y = max(img_x, 0), max(img_y, 0)
    return img_x, img_y

def coords_trans_from_patch_to_img(x, y, w, h, one_crop: OneCrop):
    if one_crop.trans_flag:
        x, y, w, h = y, x, h, w
    x, y = x + np.min(one_crop.box[:, 0]), \
           y + np.min(one_crop.box[:, 1])
    img_x, img_y = np.int0(rotated_coordinates(one_crop.angle, [(x, y)],
                                               one_crop.center[0], one_crop.center[1])[0])
    return max(img_x, 0), max(img_y, 0), w, h

def rotate_rectangle(x, y, w, h, angle):
    """

    :param x: abscissa of the left-up vertex
    :param y: ordinate of the left-up vertex
    :param w: width
    :param h: height
    :param angle:
    :return: rotated vertexes
    """
    x0, y0 = x, y
    x1, y1 = x + w, y
    x2, y2 = x + w, y + h
    x3, y3 = x, y + h
    rect_boxes = [(x0, y0), (x1, y1), (x2, y2), (x3, y3)]
    return np.int0(rotated_coordinates(angle, rect_boxes, x0, y0))

def draw_polygon(image, pts, colour=(255, 0, 0), thickness=2):
    """
    Draws a rectangle on a given image.
    :param image: What to draw the rectangle on
    :param pts: Array of point objects
    :param colour: Colour of the rectangle edges
    :param thickness: Thickness of the rectangle edges
    :return: Image with a rectangle
    """

    for i in range(0, len(pts)):
        n = (i + 1) if (i + 1) < len(pts) else 0
        cv2.line(image, (pts[i].x, pts[i].y), (pts[n].x, pts[n].y), colour, thickness)

    return image

def boundary_strip(img, var_kernel, bilater_kernel):
    img1 = img / 255.0
    mean_img = cv2.blur(img1, var_kernel) ** 2
    square_img = cv2.blur(img1 ** 2, var_kernel)
    var_img = np.sqrt(np.maximum(square_img - mean_img, 0)) * 255.0
    bilater_img = cv2.bilateralFilter(src=var_img.astype('uint8'), d=max(bilater_kernel),
                                      sigmaSpace=7, sigmaColor=7)
    eh_img = cv2.equalizeHist(bilater_img.astype('uint8'))
    erode_kernel = np.ones(bilater_kernel)
    eroded_img = cv2.erode(eh_img, erode_kernel, iterations=5)
    ret, thresh = cv2.threshold(eroded_img, 150, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if var_kernel[0] > var_kernel[1]:
            img1[:, x + w//2] = 0
        else:
            img1[y + h//2, :] = 0
    return img1 * 255.0

def module_crop(panel_img, var_size=3, bilater_size=7) -> Tuple[np.ndarray, list]:
    panel_img1 = boundary_strip(panel_img, var_kernel=(var_size, 1), bilater_kernel=(bilater_size, 1))
    panel_img2 = boundary_strip(panel_img1, var_kernel=(1, var_size), bilater_kernel=(1, bilater_size))
    ret, thresh = cv2.threshold(panel_img2.astype('uint8'), 50, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    bbx_arr = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w*h > 140:
            bbx_arr.append([x, y, w, h])
    return panel_img2, bbx_arr

def radio_rotation(img, mask_img, temperature, contour):
    """
    crop a rotated rectangle from the original image
    :param img:
    :param contour:
    :return:
    rect: contours in the form of (center(x,y), (width, height), angle of rotation)]
    box: bounding box in the form of [(x0,y0),(x1,y1),(x2,y2),(x3,y3)]
    warped_img: warped image in the form of np.array('float32')
    warped_mask: warped mask in the form of np.array('float32')
    """
    rect = cv2.minAreaRect(contour)  # 获取蓝色矩形的中心点、宽高、角度
    width = int(rect[1][0])
    height = int(rect[1][1])
    angle = rect[2]
    if width < height:  # 计算角度，为后续做准备
        angle = angle - 90
    box = cv2.boxPoints(rect)
    dst_pts = np.array([[0, height],
                        [0, 0],
                        [width, 0],
                        [width, height]], dtype="float32")
    M = cv2.getPerspectiveTransform(box, dst_pts)
    warped_img = cv2.warpPerspective(img, M, (width, height))
    warped_temperature = cv2.warpPerspective(temperature, M, (width, height))
    warped_mask = cv2.warpPerspective(mask_img, M, (width, height))
    if angle < -90:  # 对-90度以上图片的竖直结果转正
        warped_img = cv2.transpose(warped_img)
        warped_img = cv2.flip(warped_img, 0)  # 逆时针转90度，如果想顺时针，则0改为1
        warped_mask = cv2.transpose(warped_mask)
        warped_mask = cv2.flip(warped_mask, 0)  # 逆时针转90度，如果想顺时针，则0改为1
    return rect, box, warped_img, warped_temperature, warped_mask

def panel_patch_crop(img, mask_img, temperature, contour):
    """
    crop panels images from image
    :param img: a whole image
    :param contour: output contour from function cv2.findContours
    :return: a dict of parameters of one cropped objects
    """
    rect, box_origin, dst_img, dst_temperature, dst_mask = radio_rotation(img, mask_img, temperature, contour)
    center_x, center_y, angle = rect[0][0], rect[0][1], rect[2]
    # box_origin: [(x0,y0),(x1,y1),(x2,y2),(x3,y3)]
    box = np.int0(rotated_coordinates(angle, box_origin, center_x, center_y))

    return OneCrop(trans_flag=False, dst_img=dst_img, dst_temperature=dst_temperature, dst_mask=dst_mask,
                       box=box, center=rect[0], angle=-rect[2])

def margin_strip(one_crop):
    """
    Return crops that separate individual panel groups in case one cropped image
    contains more than one panel group
    :param one_crop:
    :return: list of crops including crop images and parameters
    """
    img= one_crop.img
    margin_mask = np.zeros_like(img)
    img = img / 255
    # suppose intensities of panels are higher than margin_threshold
    margin_threshold = np.mean(img) - 0.15
    margin_mask[img < margin_threshold] = 1
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(3, 1))
    open_img = cv2.morphologyEx(margin_mask, cv2.MORPH_OPEN, kernel)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(1, 3))
    open_img2 = cv2.morphologyEx(open_img, cv2.MORPH_OPEN, kernel)
    hor_total = np.sum(open_img2, axis=0)
    hor_total[0], hor_total[-1] = img.shape[0], img.shape[0]
    # boundaries are indices of margin pixels
    boundaries = np.squeeze(np.argwhere(hor_total > 0.2 * img.shape[0]))
    img = (img * 255).astype('uint8')
    crops = []
    if boundaries.size >= 4:
        for i in range(len(boundaries) - 1):
            if abs(boundaries[i] - boundaries[i+1]) > 3:
                copied_crop = deepcopy(one_crop)
                copied_crop.img = img[:, boundaries[i]+1:boundaries[i+1]]
                if _panel_filter(copied_crop.img.shape[0], copied_crop.img.shape[1]):
                    # if transposed, refresh the bounding box
                    if copied_crop.trans_flag:
                        copied_crop.box[:, 1] += (boundaries[i] + 1)
                    else:
                        copied_crop.box[:, 0] += (boundaries[i] + 1)
                    crops.append(copied_crop)
    else:
        crops.append(one_crop)
    return crops

def images_crop(raw_img, temperature, mask_img,  mask_hist_ratio=None):
    """
    Given a raw image and a mask image, return the cropped image patches of panels.
    :param raw_img: raw image
    :param mask_img: mask image
    :return: cropped image patches:
    [cropped image 0: np.array, [box, (center_abscissa, center_ordinate), angle], ...]
    """
    # mask_img[0,:], mask_img[:,0] = 0, 0
    # mask_img[:,mask_img.shape[1]-1], mask_img[mask_img.shape[0]-1,:] = 0, 0
    ret, thresh = cv2.threshold(mask_img, 200, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    new_patch_crops = []
    # new_mask_bbxs = []
    for contour in contours:
        # onecrop: [cropped image: np.array, [box, (center_abscissa, center_ordinate)pop, angle]]
        one_crop = panel_patch_crop(raw_img, mask_img, temperature, contour)
        # new_mask_bbxs.append(one_crop.box)
        # eliminate patch margins that hist mask histogram less than ratio
        # hor_i, hor_j, ver_i, ver_j = _mask_polish(one_crop.mask, mask_hist_ratio)
        hor_i, hor_j, ver_i, ver_j = 0, one_crop.img.shape[1], 0, one_crop.img.shape[0]
        # assure the patch is available
        if hor_j - hor_i > 0 and ver_j - ver_i > 0:
            # refresh crop parameters
            one_crop.img = one_crop.img[ver_i:ver_j, hor_i:hor_j]
            one_crop.center[0] += hor_i
            one_crop.center[1] += ver_i
            one_crop.trans_flag = one_crop.img.shape[0] > one_crop.img.shape[1]
            # transpose
            if one_crop.trans_flag:
                one_crop.img = one_crop.img.transpose()  # Transform from vertical to horizon
            separated_crops = margin_strip(one_crop)  # separate individual panel groups
            if separated_crops is not None:
                new_patch_crops += separated_crops
                # cv2.imwrite('demos//modules//' + str(np.random.randint(0,1000000)) + '.jpg', crop[0])
    # cv2.drawContours(raw_img, contours, -1, (0, 0, 255), 1)
    # cv2.imshow("img", raw_img)

    # mask_img_new = np.zeros((512,640, 3))
    # area = []
    # for k in range(len(new_mask_bbxs)):
    #     area.append(cv2.contourArea(new_mask_bbxs[k]))
    # max_idx = np.argsort(np.array(area))
    # for idx in max_idx:
    #     # 填充轮廓
    #     mask = cv2.drawContours(mask_img_new, new_mask_bbxs, idx, (255, 255, 255), cv2.FILLED)
    # cv2.imwrite('D:/2.jpg',mask)
    #

    return new_patch_crops#, new_mask_bbxs


# def cropped_viewer(raw_img, cropped_img):
#     plt.figure()
#     plt.imshow(raw_img)
#     ax = plt.gca()
#     cnt = 0
#     for img, img_para in cropped_img:
#         cnt += 1
#         h, w = img.shape
#         x, y = np.min(img_para[0][:, 0]), \
#                np.min(img_para[0][:, 1])
#         img_x, img_y = np.int0(rotated_coordinates(img_para[2], [(x, y)],
#                                                    img_para[1][0], img_para[1][1])[0])
#         img_x, img_y = max(img_x, 0), max(img_y, 0)
#         ax.add_patch(plt.Rectangle((img_x, img_y),
#                                    w, h, edgecolor='red', fill=False, angle=-img_para[2]))
#         plt.text(img_x, img_y, str(cnt), color='r')
#     plt.show()


def mask_expand(mask_img: np.ndarray):
    img_shape = mask_img.shape
    mask = Image.new('L', (img_shape[1], img_shape[0]), 0)
    ret, thresh = cv2.threshold(mask_img, 200, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        rect = cv2.minAreaRect(contour)
        points = cv2.boxPoints(rect)
        points = [tuple([math.floor(pt1) for pt1 in pt]) for pt in points]
        ImageDraw.Draw(mask).polygon(points, fill=255)
    return np.array(mask)


def _mask_polish(mask_crop, hist_rotio=None):
    """
    search the available part of a panel patch,
    eliminate margins that the value of horizontal and vertical histogram less than hist_ratio
    :param mask_crop:
    :return:
    """
    if hist_rotio is None:
        return 0, mask_crop.shape[1], 0, mask_crop.shape[0]
    hor_proj = np.sum(mask_crop/255, axis=0)  # horizontal projection
    for i in range(len(hor_proj)):  # search the start line
        if hor_proj[i] > hist_rotio * mask_crop.shape[0]:
            break
    j = len(hor_proj) - 1
    for j in range(len(hor_proj) - 1, i, -1):  # search the end line
        if hor_proj[j] > hist_rotio * mask_crop.shape[0]:
            break
    hor_i, hor_j = i + 1, j
    ver_proj = np.sum(mask_crop/255, axis=1)
    for i in range(len(ver_proj)):  # search the start line
        if ver_proj[i] < hist_rotio * mask_crop.shape[1]:
            break
    j = len(ver_proj) - 1
    for j in range(len(ver_proj) - 1, i, -1):  # search the end line
        if ver_proj[j] < hist_rotio * mask_crop.shape[1]:
            break
    ver_i, ver_j = i + 1, j
    return hor_i, hor_j, ver_i, ver_j

def _img_flush():
    pass

def _panel_filter(width, height, sea_flag=True):
    # filter
    if not sea_flag:
        return max(width, height) / min(width, height) > 2 and width * height > 2000
    else:
        return width * height > 2000