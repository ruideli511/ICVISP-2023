import numpy as np
from imageutils.shape_detection import rotate_rectangle

def temperature_filter(temperature, expanded_mask, bbxs, temperature_res, sensor):
    m = 35  # find max_index
    nn = 1  # for small neighborhood
    n = 3  # for large neighborhood

    # temperature0 = temperature
    # mask_img0 = expanded_mask
    # img_tmp0 = np.multiply(temperature0, mask_img0 / 255)

    temperature = np.pad(temperature, n+m)
    mask_img = np.pad(expanded_mask, n+m)
    img_tmp = np.multiply(temperature, mask_img/255)
    height, width = img_tmp.shape
    new_bbxs=[]

    for bbx in bbxs:
        x, y, w, h, angle = bbx
        x, y = max(x, 0), max(y, 0)
        rotated_vertex = rotate_rectangle(x, y, w, h, angle=angle)
        col = int((rotated_vertex[0][0] + rotated_vertex[1][0]) / 2) + m + n
        row = int((rotated_vertex[0][1] + rotated_vertex[3][1]) / 2) + m + n
        # y, x = bbx[0]+m+n, bbx[1]+m+n
        local_one_tmp = img_tmp[row-m:row+m+1,col-m:col+m+1]  # 5*5
        max_index = np.unravel_index(np.argmax(local_one_tmp, axis=None), local_one_tmp.shape)
        col = col - m + max_index[1]
        row = row - m + max_index[0]
        local_one = img_tmp[row - nn:row + nn + 1, col - nn:col + nn + 1]
        mean_one = np.sum(local_one)/(len(local_one[np.nonzero(local_one)]))
        local_two = img_tmp[row - (nn+n):row + (nn+n+1), col - (nn+n):col + (nn+n+1)]
        mean_two = (np.sum(local_two)-np.sum(local_one))/(len(local_two[np.nonzero(local_two)]) - len(local_one[np.nonzero(local_one)]))
        if (mean_one - mean_two) > temperature_res:
            new_bbxs.append(bbx)
    return new_bbxs
