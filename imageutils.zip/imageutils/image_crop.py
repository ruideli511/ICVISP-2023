class OneCrop(object):
    def __init__(self, trans_flag=False, dst_img=None, dst_temperature=None, dst_mask=None,
                 box=[], center=[], angle=0):
        self.trans_flag = trans_flag
        self.img = dst_img
        self.temperature = dst_temperature
        self.mask = dst_mask
        self.box = box
        self.center = list(center)
        self.angle = angle