import numpy as np
import cv2

def normalize(v):
    return (v - np.min(v)) / (np.max(v) - np.min(v))

def panel_filter(width, height, sea_flag=False):
    # filter
    if not sea_flag:
        return max(width, height) / min(width, height) > 2 and width * height > 2000
    else:
        return width * height > 2000

def myclose(img: np.ndarray, kernel_shape=(3,3)):
    kernel = np.ones(kernel_shape)
    data1 = cv2.dilate(img, kernel)
    ret, thresh = cv2.threshold(data1, 200, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        data1[y:y+h,x:x+w] = 255
    return cv2.erode(data1, kernel)

def myopen(img: np.ndarray, kernel_shape=(3,3)):
    kernel = np.ones(kernel_shape)
    data1 = cv2.erode(img, kernel)
    ret, thresh = cv2.threshold(data1, 200, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        data1[y:y+h,x:x+w] = 255
    return cv2.dilate(data1, kernel)

