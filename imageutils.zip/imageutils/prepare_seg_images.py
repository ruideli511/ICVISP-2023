import numpy as np
import os
from PIL import Image, ImageOps
from segmentron.config import cfg
from thermal_parser.thermal import Thermal
import cv2 as cv

def _margin_removal(img):
    img[:25, :] = 0
    img[475:, :] = 0
    img[:, :25] = 0
    img[:, 600:] = 0
    return img

def __img_transform(img, type='image'):
    w, h = img.size
    padw, padh = 0, 0
    if w > h:
        oh = cfg.TRAIN.BASE_SIZE
        ow = int(1.0 * w * oh / h)
    else:
        ow = cfg.TRAIN.BASE_SIZE
        oh = int(1.0 * h * ow / w)
    if type == 'image':
        img = img.resize((ow, oh), Image.BILINEAR)
    elif type == 'mask':
        img = img.resize((ow, oh), Image.NEAREST)
    # Assure the image height and weight are divisible by unet output stride 32
    if cfg.MODEL.MODEL_NAME.lower() == 'unet' and \
            (oh % 32 != 0 or ow % 32 != 0):
        padh = (32 * (oh // 32 + (oh % 32 != 0))) - oh
        padw = (32 * (ow // 32 + (ow % 32 != 0))) - ow
        img = ImageOps.expand(img, border=(0, 0, padw, padh), fill=0)
    return img, (padw, padh)

def prepare_images(img_path, transform=None, sensor='h20t'):
    if cfg.DATASET.NAME == 'pv_ir':
        if sensor == 'xt2' or img_path.endswith('R.JPG'):
            img = Image.open(img_path)
            if img.layers == 3:
                img, _, _ = img.split()
            temperature = None
        else:
            dji_irpAddress = cfg.ROOT_PATH + '/segmentron/release_x86/dji_irp.exe'
            raw_address = img_path[0:img_path.rfind('/')] + '/raw/'
            if not os.path.exists(raw_address):
                os.mkdir(raw_address)
            out_address = raw_address + img_path.split('/')[-1][:-4] + ".raw"
            if not os.path.exists(out_address):
                cmd = dji_irpAddress + " -s " + img_path + \
                      " -a process -o " + out_address + " -p white_hot"
                process = os.popen(cmd)
                process.read()

            img = np.fromfile(out_address, dtype='uint8')
            img = Image.fromarray(img.reshape(512, 640, 3))
            img, _, _ = img.split()

            out_address_temperature = raw_address + img_path.split('/')[-1][:-4] + "_temperature.raw"
            if not os.path.exists(out_address_temperature):
                cmd_temperature = dji_irpAddress + " -s " + img_path + " -a measure -o " + out_address_temperature + " --measurefmt float32"
                process_temperature = os.popen(cmd_temperature)
                process_temperature.read()
            img_temperature = np.fromfile(out_address_temperature, dtype='float32')
            temperature = Image.fromarray(img_temperature.reshape(512, 640))
            # img_temperature = None
            temperature = np.array(temperature)

    else:
        img = Image.open(img_path).convert('RGB')
        temperature = None
        # img = unevenLightCompensate(img, 8)
    pads = (0, 0)
    if cfg.TRAIN.BASE_SIZE is not None:
        img, pads = __img_transform(img, type='image')
    if transform is not None:
        img = transform(img)
    return temperature, img, pads
