# coding: utf-8
from typing import Union

import cv2 as cv
import numpy as np
from PIL import Image
from shapely.geometry import Polygon


def merge_bboxes(bboxes: list, image_size: tuple):
    """ 合并边界框

    Paramters
    ---------
    bboxes: list of shape `(n_boxes, 4)`
        边界框列表，格式为 `(x, y, w, h)`

    image_size: tuple
        图像尺寸，格式为 `(w, h)`

    Returns
    -------
    merged_bboxes: list of shape `(n_boxes, 4)`
        合并后的边界框列表，格式为 `(x, y, w, h)`
    """
    w, h = image_size

    # 创建遮罩图像
    image = np.zeros((h, w), np.uint8)
    for x, y, bw, bh in bboxes:
        image[y:y+bh, x:x+bw] = 255

    # 图像闭操作，合并相邻边界框
    image = cv.morphologyEx(image, cv.MORPH_CLOSE,
                            np.ones((7, 7)), iterations=4)
    # Image.fromarray(image).show()

    # 提取轮廓
    image[:, :2], image[:, -2:] = 0, 0
    image[:2, :], image[-2:, :] = 0, 0
    contours, _ = cv.findContours(
        image, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

    # 将轮廓转换为边界框
    merged_bboxes = []
    for contour in contours:
        if cv.contourArea(contour) < 500:
            continue

        x, y, bw, bh = cv.boundingRect(contour)
        merged_bboxes.append([x, y, bw, bh])

    return merged_bboxes


def iou(bbox1: Union[list, np.ndarray], bbox2: Union[list, np.ndarray]):
    """ 计算两个边界框的交并比

    Parameters
    ----------
    bbox1, bbox2: list or `np.ndarray` of shape `(4, 2)`
        边界框，每个元素为顶点
    """
    a = Polygon(bbox1)
    b = Polygon(bbox2)
    return a.intersection(b).area / a.union(b).area


def remove_overlap_bboxes(bboxes1: Union[list, np.ndarray], bboxes2: Union[list, np.ndarray], iou_thresh=0.4):
    """ 移除重叠的边界框

    bboxes1: list or `np.ndarray` of shape `(n_boxes, 4, 2)`
        等待筛选边界框

    bboxes2: list or `np.ndarray` of shape `(n_boxes, 4, 2)`
        用于计算重叠程度边界框

    iou_thresh: float
        交并比阈值，大于此阈值的边界框将被移除

    Returns
    -------
    keeps: list of shape `(n_keeps, 4, 2)`
        筛选后的边界框

    indexes: list of shape `(n_keeps, )`
        保留的边界框的索引
    """
    keeps = []
    indexes = []

    for i, box1 in enumerate(bboxes1):
        is_keep = True
        for box2 in bboxes2:
            if iou(box1, box2) > iou_thresh:
                is_keep = False
                break

        if is_keep:
            keeps.append(box1)
            indexes.append(i)

    return keeps, indexes
