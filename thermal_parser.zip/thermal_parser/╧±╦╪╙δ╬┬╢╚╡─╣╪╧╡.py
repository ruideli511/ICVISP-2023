import cv2 as cv
import numpy as np
import pygame as pygame
import gc
from thermal import Thermal

thermal = Thermal(
    dirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libdirp.dll',
    dirp_sub_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_dirp.dll',
    iirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_iirp.dll',
    exif_filename='plugins/exiftool-12.35.exe',
    dtype=np.float32,
)
def printTemperatureIntheRightPos(tempMessage, x, y, imgWidth):
    if x + 30 < imgWidth and y - 30 > 0:
        screen.blit(tempMessage, [x + 10, y - 10])
    elif x + 30 > imgWidth and y - 30 < 0:
        screen.blit(tempMessage, [x - 30, y + 20])
    elif x + 30 > imgWidth:
        screen.blit(tempMessage, [x - 30, y - 10])
    elif y - 30 < 0:
        screen.blit(tempMessage, [x + 10, y + 10])


# 图片位置
imageAddress = 'C:\\Users\\MSI\\Desktop\\h20t\\DJI_0237_R.JPG'

# 温度
temperature = thermal(image_filename=imageAddress)
# 读入像素值
grayValue = cv.imread(imageAddress, 0)
#将像素值和温度读入一维数组进行拟合
aa,cc = [], []
for i in range(0, 512):
    for j in range(0, 640):
        aa.append(float(temperature[i][j]))
        cc.append(float(grayValue[i][j]))

#线性拟合得到参数
parm = np.polyfit(aa,cc,1)
pygame.init()
img = pygame.image.load(imageAddress)
screen = pygame.display.set_mode([grayValue.shape[1], grayValue.shape[0]])

myfont =pygame.font.Font(None,20)
while 1:
    screen.blit(img, [0, 0])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gc.collect()
            exit()

    position = pygame.mouse.get_pos()
    x = position[0]
    y = position[1]

    temperature1 = temperature[y][x]
    tempMessage = myfont.render(str(temperature1), True, [0, 255, 0])
    printTemperatureIntheRightPos(tempMessage, x, y, grayValue.shape[1])

    # 设置像素值与线性拟合后得到的像素值的差，在图片的大部分区域，这个差值都很小
    pygame.display.set_caption(str(grayValue[y][x] - parm[0] * temperature1 - parm[1]))

    pygame.display.flip()

