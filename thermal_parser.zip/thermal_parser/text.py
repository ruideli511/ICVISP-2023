import cv2 as cv
import numpy as np
import pygame as pygame
import gc
import os
from thermal import Thermal

thermal = Thermal(
    dirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libdirp.dll',
    dirp_sub_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_dirp.dll',
    iirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_iirp.dll',
    exif_filename='plugins/exiftool-12.35.exe',
    dtype=np.float32,
)

# 图片位置
imageAddress = 'C:/Users/MSI/Desktop/data/xt2/original/'
in_files = [fn for fn in os.listdir(imageAddress) if fn.endswith('R.jpg') or fn.endswith('R.JPG')]
for k, fn in enumerate(in_files):
    temperature, image_normal = thermal(image_filename=imageAddress + fn)
    cv.imwrite('C:/Users/MSI/Desktop/data/xt2/ours/' + fn, image_normal)



# white_hot = cv.imread('C:\\Users\\MSI\\Desktop\\h20t\\DJI_0001_R1.JPG')

# data_value = temperature
# data_shape = data_value.shape
# print(data_value.shape)
# data_rows = data_shape[0]
# data_cols = data_shape[1]
# new_data=np.zeros(shape=(data_rows+1,data_cols))
# # origin = data_origin[0,:]
# for i in range(0, data_rows, 1):
#     for j in range(0, data_cols, 1):
#         data_col_min_values = min(data_value[:,j])
#         data_col_max_values = max(data_value[:,j])
#         new_data[i][j] = (data_value[i][j] - data_col_min_values) / (data_col_max_values - data_col_min_values)
#         new_data[i][j] = new_data[i][j] * 255

def printTemperatureIntheRightPos(tempMessage, x, y, imgWidth):
    if x + 30 < imgWidth and y - 30 > 0:
        screen.blit(tempMessage, [x + 10, y - 10])
    elif x + 30 > imgWidth and y - 30 < 0:
        screen.blit(tempMessage, [x - 30, y + 20])
    elif x + 30 > imgWidth:
        screen.blit(tempMessage, [x - 30, y - 10])
    elif y - 30 < 0:
        screen.blit(tempMessage, [x + 10, y + 10])

pygame.init()
img1 = cv.imread(imageAddress)
img = pygame.image.load(imageAddress)
screen = pygame.display.set_mode([img1.shape[1], img1.shape[0]])

myfont = pygame.font.Font(None, 20)
while 1:
    screen.blit(img, [0, 0])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gc.collect()
            exit()

    position = pygame.mouse.get_pos()
    x = position[0]
    y = position[1]

    temperature1 = temperature[y][x]
    tempMessage = myfont.render(str(temperature1), True, [0, 255, 0])
    printTemperatureIntheRightPos(tempMessage, x, y, img1.shape[1])

    pygame.display.flip()



assert isinstance(temperature, np.ndarray)