import time

import cv2 as cv
import numpy as np
import pygame as pygame
import gc
from matplotlib import pyplot as plt

from thermal import Thermal
from PIL import Image
thermal = Thermal(
    dirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libdirp.dll',
    dirp_sub_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_dirp.dll',
    iirp_filename='plugins/dji_thermal_sdk_v1.1_20211029/windows/release_x64/libv_iirp.dll',
    exif_filename='plugins/exiftool-12.35.exe',
    dtype=np.float32,
)
# 图片位置
imageAddress = 'C:\\Users\\MSI\\Desktop\\h20t\\DJI_0003_R.JPG'
# 温度
temperature = thermal(image_filename=imageAddress)
grayValue = cv.imread(imageAddress,0)


tt=temperature.reshape(512 * 640)
gg=grayValue.reshape(512 * 640)
# 线性拟合得到参数
parm = np.polyfit(tt, gg, 1)

grayValue_fit=temperature
# 对每个点进行温度到灰度的转换
for i in range(0, 512):
    for j in range(0, 640):
        grayValue_fit[i][j] = int(parm[0] * grayValue_fit[i][j] + parm[1])

grayValue_fit=np.array(grayValue_fit,np.uint8)
cv.imshow('original Image',grayValue)
cv.imshow('afterFit Image',grayValue_fit)
cv.waitKey(0)
