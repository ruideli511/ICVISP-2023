import cv2
import numpy as np
from tkinter import filedialog
import matplotlib.pyplot as plt


def cv_imread(filePath):
    '''读取图像，解决imread不能读取中文路径的问题

    :param filePath: 文件路径（可以是中文路径）
    :return: 返回选取的图像rgb格式
    '''
    cv_img = cv2.imdecode(np.fromfile(filePath, dtype=np.uint8), -1)
    # imdecode读取的是rgb，如果后续需要opencv处理的话，需要转换成bgr，转换后图片颜色会变化
    cv_img = cv2.cvtColor(cv_img, cv2.COLOR_RGB2BGR)
    return cv_img


def choseImage(type=1):
    '''弹出文件选择窗口选择后读取某张图像

    :param type: type->1 返回原图 type->2 返回灰度图

    :return: 图像文件路径，返回选取的图像
    '''
    ftypes = [
        ("JPG", "*.jpg;*.JPG;*.JPEG"),
        ("PNG", "*.png;*.PNG"),
        ("GIF", "*.gif;*.GIF"),
        ("All files", "*.*")
    ]
    file_path = filedialog.askopenfilename(filetypes=ftypes)
    image_src = cv_imread(file_path)
    if type == 1:
        return file_path, image_src
    elif type == 2:
        gray_image_src = cv2.cvtColor(image_src, cv2.COLOR_BGR2GRAY)
        return file_path, gray_image_src


def IR_warpPerspective_to_vis(IrImg, VisImg, pos):
    '''通过warpPerspective方法实现红外图像的透视变换

    :param IrImg: 红外灰度图
    :param VisImg: 可见光灰度图
    :param pos: 透视矩阵
    :return: 红外矩阵变化后和可见光图像的融合图
    '''
    # ------------------warpPerspective--------------
    H = np.array([[pos[0], pos[1], pos[2]], [pos[3], pos[4],
                 pos[5]], [pos[6], pos[7], 1]], np.float32)
    image_output = cv2.warpPerspective(
        IrImg, H, (VisImg.shape[1], VisImg.shape[0]))
    viewImage(image_output)
    match_img = cv2.addWeighted(image_output, 0.5, VisImg, 0.5, 0)
    viewImage(match_img)
    return image_output, match_img


def viewImage(image):
    '''显示图像

    :param image: 需要展示的图片
    :return:
    '''
    cv2.namedWindow('Display', cv2.WINDOW_KEEPRATIO)
    cv2.imshow('Display', image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def plt_show(img):
    if img.ndim == 2:
        plt.imshow(img, cmap='gray')
    else:
        plt.imshow(img)
    plt.show()
