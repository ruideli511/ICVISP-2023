# coding: utf-8
from typing import Union

import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt
from skimage import measure, transform
from torch import cuda

from .net.cnn_feature import cnn_feature_extract
from .net.model import D2Net
from .plotmatch import plot_matches


class ImageRegister:
    """ 图像配准类 """

    def __init__(self, residual_thresh=30, model_path="model/d2_tf.pth"):
        """
        Parameters
        ----------
        residual_thresh: float
            Maximum distance for a data point to be classified as an inlier

        model_path: str
            the path of d2net weight file
        """
        self.residual_thresh = residual_thresh
        self.homography_mat = None

        self.d2net = D2Net(
            model_file=model_path,
            use_relu=True,
            use_cuda=cuda.is_available()
        )

    def match(self, vis_image: np.ndarray, ir_image: np.ndarray, plot=False):
        """ 配准可见光图像和红外图像

        Parameters
        ----------
        vis_image: `np.ndarray`
            可见光图像

        ir_image: `np.ndarray`
            红外图像

        plot: bool
            是否绘制匹配的特征点对

        Returns
        -------
        H: `np.ndarray` of shape `(3, 3)`
            单应性矩阵
        """
        vis_image = cv.resize(
            vis_image, ir_image.shape[1::-1], interpolation=cv.INTER_AREA)

        # 提取特征
        kps_left, sco_left, des_left = cnn_feature_extract(
            self.d2net, vis_image, nfeatures=-1)
        kps_right, sco_right, des_right = cnn_feature_extract(
            self.d2net, ir_image, nfeatures=-1)

        # Flann 特征匹配
        index_params = dict(algorithm=1, trees=5)
        search_params = dict(checks=40)
        flann = cv.FlannBasedMatcher(index_params, search_params)
        matches = flann.knnMatch(des_left, des_right, k=2)

        good_matches = []
        locations_1_to_use = []
        locations_2_to_use = []

        # 统计平均距离差
        disdif_avg = 0
        for m, n in matches:
            disdif_avg += n.distance - m.distance

        disdif_avg = disdif_avg / len(matches)

        # 匹配对筛选
        for m, n in matches:
            if n.distance <= m.distance + disdif_avg:
                continue

            good_matches.append(m)
            p2 = cv.KeyPoint(kps_right[m.trainIdx]
                             [0], kps_right[m.trainIdx][1], 1)
            p1 = cv.KeyPoint(kps_left[m.queryIdx][0],
                             kps_left[m.queryIdx][1], 1)
            locations_1_to_use.append([p1.pt[0], p1.pt[1]])
            locations_2_to_use.append([p2.pt[0], p2.pt[1]])

        # Perform geometric verification using RANSAC.
        locations_1_to_use = np.array(locations_1_to_use)
        locations_2_to_use = np.array(locations_2_to_use)
        model, inliers = measure.ransac(
            (locations_1_to_use, locations_2_to_use),
            transform.AffineTransform,
            min_samples=3,
            residual_threshold=self.residual_thresh,
            max_trials=1000
        )

        self.homography_mat = model.params

        # 绘制配准结果
        if plot:
            inlier_idxs = np.nonzero(inliers)[0]
            matches = np.column_stack((inlier_idxs, inlier_idxs))

            _, ax = plt.subplots()
            plot_matches(
                ax,
                vis_image,
                ir_image,
                locations_1_to_use,
                locations_2_to_use,
                matches,
                plot_matche_points=False,
                matchline=True,
                matchlinewidth=0.3
            )

        return model.params

    def map_points(self, bboxes: Union[list, np.ndarray], vis_size: tuple, ir_size: tuple) -> np.ndarray:
        """ 将可见光图像上的边界框映射到红外图像上

        Parameters
        ----------
        points: list of `np.ndarray` of shape `(n_boxes, 4, 2)`
            可见光图像上的边界框

        vis_size: tuple
            可见光图像尺寸，格式为 `(width, height)`

        ir_size: tuple
            红外图像尺寸，格式为 `(width, height)`

        Returns
        -------
        points: `np.ndarray` of shape `(n_boxes, 4, 2)`
            红外图像上的边界框
        """
        if self.homography_mat is None:
            raise Exception("图像未经过配准")

        if len(bboxes) == 0:
            return np.array([])

        bboxes = np.float32(bboxes)
        bboxes[:, :, 0] *= ir_size[0]/vis_size[0]
        bboxes[:, :, 1] *= ir_size[1]/vis_size[1]
        bboxes = cv.perspectiveTransform(bboxes, self.homography_mat)
        return bboxes.astype(int)


    def map_image(self, image: np.ndarray, size: tuple):
        """ 将可见光图像映射到红外图像坐标系中

        Parameters
        ----------
        image: `np.ndarray`
            可见光图像

        size: tuple
            目标图像尺寸，格式为 `(width, height)`
        """
        if self.homography_mat is None:
            raise Exception("图像未经过配准")

        image = cv.resize(image, size, interpolation=cv.INTER_AREA)
        return cv.warpPerspective(image, self.homography_mat, size)
