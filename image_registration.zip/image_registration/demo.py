import cv2
import matplotlib.pyplot as plt
import numpy as np
from skimage import measure, transform

from image_registration.plotmatch import plot_matches
from image_registration.image_basic_actions import choseImage, plt_show
from image_registration.net.cnn_feature import cnn_feature_extract


def IR_warpPerspective_to_vis(IrImg, VisImg, pos):
    '''通过warpPerspective方法实现红外图像的透视变换

    :param IrImg: 红外灰度图
    :param VisImg: 可见光灰度图
    :param pos: 透视矩阵
    :return: 红外矩阵变化后和可见光图像的融合图
    '''
    # ------------------warpPerspective--------------
    H = np.array([[pos[0], pos[1], pos[2]], [pos[3], pos[4],
                 pos[5]], [pos[6], pos[7], 1]], np.float32)
    image_output = cv2.warpPerspective(
        IrImg, H, (VisImg.shape[1], VisImg.shape[0]))
    # viewImage(image_output)
    match_img = cv2.addWeighted(image_output, 0.5, VisImg, 0.5, 0)
    plt_show(match_img)
    return image_output, match_img




_RESIDUAL_THRESHOLD = 30



# read left image 弹出窗口选择文件
img1_path, vis_image = choseImage(1)
img2_path, ir_image = choseImage(1)


# 缩小可见光大小 使其和红外尺寸相同 图1是可见光
vis_image = cv2.resize(vis_image, None, fx=ir_image.shape[1] / vis_image.shape[1],
                    fy=ir_image.shape[0] / vis_image.shape[0], interpolation=cv2.INTER_AREA)

kps_left, sco_left, des_left = cnn_feature_extract(vis_image,  nfeatures=-1)
kps_right, sco_right, des_right = cnn_feature_extract(ir_image,  nfeatures=-1)



# Flann特征匹配
FLANN_INDEX_KDTREE = 1
index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
search_params = dict(checks=40)
flann = cv2.FlannBasedMatcher(index_params, search_params)
matches = flann.knnMatch(des_left, des_right, k=2)

good_matches = []
locations_1_to_use = []
locations_2_to_use = []

# 匹配对筛选
min_dist = 1000
max_dist = 0
disdif_avg = 0
# 统计平均距离差
for m, n in matches:
    disdif_avg += n.distance - m.distance
disdif_avg = disdif_avg / len(matches)

for m, n in matches:
    # 自适应阈值
    if n.distance > m.distance + disdif_avg:
        good_matches.append(m)
        p2 = cv2.KeyPoint(kps_right[m.trainIdx][0],
                          kps_right[m.trainIdx][1],  1)
        p1 = cv2.KeyPoint(kps_left[m.queryIdx][0], kps_left[m.queryIdx][1], 1)
        locations_1_to_use.append([p1.pt[0], p1.pt[1]])
        locations_2_to_use.append([p2.pt[0], p2.pt[1]])

#goodMatch = sorted(goodMatch, key=lambda x: x.distance)
print('match num is %d' % len(good_matches))
locations_1_to_use = np.array(locations_1_to_use)
locations_2_to_use = np.array(locations_2_to_use)

# Perform geometric verification using RANSAC.
model, inliers = measure.ransac((locations_1_to_use, locations_2_to_use),
                                transform.AffineTransform,
                                min_samples=3,
                                residual_threshold=_RESIDUAL_THRESHOLD,
                                max_trials=1000)

print('Found %d inliers' % sum(inliers))

inlier_idxs = np.nonzero(inliers)[0]
# 最终匹配结果
matches = np.column_stack((inlier_idxs, inlier_idxs))

# Visualize correspondences, and save to file.
# 1 绘制匹配连线
plt.rcParams['savefig.dpi'] = 100  # 图片像素
plt.rcParams['figure.dpi'] = 300  # 分辨率
# 设置figure_size尺寸设置figure_size尺寸dpi=150
plt.rcParams['figure.figsize'] = (4.0, 3.0)
_, ax = plt.subplots()
plot_matches(
    ax,
    vis_image,
    ir_image,
    locations_1_to_use,
    locations_2_to_use,
    matches,
    plot_matche_points=False,
    matchline=True,
    matchlinewidth=0.3
)
ax.axis('off')
ax.set_title('')
plt.show()

# 融合图展示
# pos = [0, 0, model.transcation, 0, 6.751330049261084, 215.6595073891624, 0, 0]
# ir_tr,match_img = IR_warpPerspective_to_vis(image1,image2,pos)
image_output = cv2.warpPerspective(
    vis_image, model.params, (ir_image.shape[1], ir_image.shape[0]))

match_img = cv2.addWeighted(image_output, 0.5, ir_image, 0.5, 0)
plt.axis('off')
plt_show(match_img)
