import os
import sys
import torch
import numpy as np

cur_path = os.path.abspath(os.path.dirname(__file__))
root_path = os.path.split(cur_path)[0]
sys.path.append(root_path)

from PIL import Image
from torchvision import transforms
from segmentron.models.model_zoo import get_segmentation_model
from segmentron.utils.options import parse_args
from segmentron.utils.default_setup import default_setup
from segmentron.config import cfg
from imageutils.prepare_seg_images import prepare_images


batch_size = 2
def demo():
    args = parse_args()
    cfg.update_from_file(args.config_file)
    cfg.PHASE = 'test'
    cfg.ROOT_PATH = root_path
    cfg.check_and_freeze()
    default_setup(args)

    # output folder
    if os.path.isdir(args.input_img):
        output_root = args.input_img.strip('/') + '_mask'
    output_dir = os.path.join(output_root, 'vis_result_{}_{}_{}_{}'.format(
        cfg.MODEL.MODEL_NAME, cfg.MODEL.BACKBONE, cfg.DATASET.NAME, cfg.TIME_STAMP))
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # image transform
    if cfg.DATASET.NAME == 'pv_ir':
        transform = transforms.Compose([
            transforms.ToTensor()
        ])
    else:
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(cfg.DATASET.MEAN, cfg.DATASET.STD)
        ])

    model = get_segmentation_model().to(args.device)
    model.eval()

    if os.path.isdir(args.input_img):
        img_paths = [os.path.join(args.input_img, x) for x in os.listdir(args.input_img)]
    else:
        img_paths = [args.input_img]
    batch_images = []
    batch_image_paths = []
    for img_path in img_paths:
        _, image, pads = prepare_images(img_path, transform, sensor=cfg.DATASET.SENSOR)
        batch_images.append(image)
        batch_image_paths.append(img_path)
        if len(batch_images) == batch_size:
            images = torch.stack(batch_images)
            images = images.to(device=args.device)
            with torch.no_grad():
                output = model(images)[0]
            images = [image[:image.shape[-2] - pads[0], :image.shape[-1] - pads[1]] for image in
                      images.squeeze(1).cpu()]
            preds = torch.argmax(output, 1).squeeze(1).cpu().data.numpy()
            for idx, pred in enumerate(preds):
                # image = (images[idx].numpy() * 255.0).astype('uint8')
                pred = pred.astype('uint8') * 255
                pred = Image.fromarray(pred)
                # staked = np.hstack((image, pred))
                # staked = Image.fromarray(staked)
                outname = os.path.splitext(os.path.split(batch_image_paths[idx])[-1])[0] + '.png'
                pred.save(os.path.join(output_dir, outname))
            batch_images = []
            batch_image_paths = []


if __name__ == '__main__':
    demo()
