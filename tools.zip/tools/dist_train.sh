#!/usr/bin/env bash

PYTHON=${PYTHON:-"/data/code/xcq/SegmenTron-master/env/bin/python"}

CONFIG="/data/code/xcq/SegmenTron-master/configs/pv_unet_dist.yaml"
GPUS=$4
torchrun --nproc_per_node=4 \
    $(dirname "$0")/train.py --config-file $CONFIG
