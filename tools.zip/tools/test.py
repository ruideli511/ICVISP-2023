import cv2
import numpy as np

img = cv2.imread('D:/1.png')

# 反转 黑白变换  一般不需要这一步，我这张图片是在找轮廓的时候有图像的四个边也会
# # 被当成轮廓，所以我先反转一下黑白交换

black = 255 - img

# 彩图转为灰度图
gray = cv2.cvtColor(black, cv2.COLOR_BGR2GRAY)
# 转为二值图像
t, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

# 找到所有轮廓，记录轮廓的每一个点
contours, hierarchy = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

area = []
for k in range(len(contours)):
    area.append(cv2.contourArea(contours[k]))
# 轮廓索引
max_idx = np.argsort(np.array(area))
mask = img.copy()
# 按轮廓索引填充颜色
for idx in max_idx:
    # 填充轮廓
    mask = cv2.drawContours(mask, contours, idx, (0, 0, 255), cv2.FILLED)

cv2.imshow('mask', mask)
cv2.waitKey()
cv2.destroyAllWindows()