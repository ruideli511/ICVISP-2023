from UI_system import *
# from register import  register

if __name__ == '__main__':
    # # 先判断用户的认证信息
    # reg = register()
    # reg_flag = reg.checkAuthored()
    # reg_cnt = 0
    # while not reg_flag:
    #     # 未认证用户进行注册
    #     # TODO: 可追加连续输入多次错误注册码退出功能
    #     reg_flag = reg.regist()
    #     if not reg_flag:
    #         print("Wrong register code, please check and input your register code again:")
    #         print("You may contact your administer for a register code with your unique id:")
    #         print(reg.getCVolumeSerialNumber())
    #         reg_cnt += 1
    #     else:
    #         break

    app = QApplication(sys.argv)
    UI_1 = regist()
    UI_1.show()
    sys.exit(app.exec_())

