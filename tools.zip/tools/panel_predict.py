import os
import cv2
import numpy as np
import math
import time
# import warnings
from detectors.detectors import detect_all
from utils.evaluate import evaluate_pr
from utils.predict import load_model, predict
from utils.data_vis import view_and_save
from imageutils.temperature_filter import temperature_filter


def panels_predict(file_path, save_path, volume=10, temperature_res=1,
                   spot_flag=True, line_flag=True, strip_flag=True,
                   flo_flag=True, facet_flag=True, group_flag=True,
                   desert_flag=False, roof_flag=False, ground_flag=False,
                   mountain_flag=False, sea_flag=True,
                   h20t_flag=False, xt2_flag=False):
    model, transform, device = load_model()
    spot_cnt_per, line_cnt_per, flo_cnt_per, facet_cnt_per, group_cnt_per, strip_cnt_per = [], [], [], [], [], []
    spot_cnt, line_cnt, flo_cnt, facet_cnt, group_cnt, strip_cnt = 0, 0, 0, 0, 0, 0
    img_name_rec, spot_bbx_rec, line_bbx_rec, flo_bbx_rec, \
    strip_bbx_rec, facet_bbx_rec, group_bbx_rec = [], [], [], [], [], [], []
    in_files = [file_path + fn for fn in os.listdir(file_path) if fn.endswith('R.jpg') or fn.endswith('R.JPG') or fn.endswith('T.jpg') or fn.endswith('T.JPG')]
    in_files = in_files[:50]
    start = time.time()
    time_recoder = {'seg': np.zeros((len(in_files)//volume, 1)),
                    'preprocess': np.zeros((len(in_files)//volume, 1)),
                    'detect': np.zeros((len(in_files), 1))}
    sensor = 'h20t' if h20t_flag else 'xt2'
    for batch_idx in range(math.ceil(len(in_files)/volume)):
        batch_img_files = in_files[batch_idx * volume:min((batch_idx + 1) * volume,
                                                          len(in_files))]
        temperatures, images, masks = predict(batch_img_files, model, transform, device, sensor, batch_idx, time_recoder)
        for idx, fn in enumerate(batch_img_files):
            raw_img = np.array(images[idx])
            temperature = temperatures[idx]
            # raw_img = cv2.bilateralFilter(src=raw_img, d=7, sigmaSpace=7, sigmaColor=50)
            raw_img = ((raw_img - np.min(raw_img)) / (np.max(raw_img) - np.min(raw_img)) * 255.0).astype('uint8')
            mask_img = np.array(masks[idx])
            mask_img = cv2.medianBlur(mask_img, 9)  # 中值滤波

            # mask_img_new = np.zeros((mask_img.shape[0],mask_img.shape[1],3))
            time_recoder['detect'][batch_idx*volume + idx] = time.time()
            spot_bbx, line_bbx, flo_bbx, strip_bbx, facet_bbx, group_bbx, expanded_mask = \
                detect_all(raw_img, mask_img, temperature, spot_flag, line_flag, flo_flag, \
                           strip_flag, facet_flag, group_flag, \
                           desert_flag=desert_flag, sea_flag=sea_flag)
            time_recoder['detect'][batch_idx*volume + idx] = time.time() - time_recoder['detect'][batch_idx*volume + idx]
            if sensor == 'xt2':  # thres
                # [x,y,w,h,angle]
                spot_bbx = temperature_filter(temperature, expanded_mask, spot_bbx, temperature_res, sensor)
                line_bbx = temperature_filter(temperature, expanded_mask, line_bbx, temperature_res, sensor)
                flo_bbx = temperature_filter(temperature, expanded_mask, flo_bbx, temperature_res, sensor)
                strip_bbx = temperature_filter(temperature, expanded_mask, strip_bbx, temperature_res, sensor)
            else:
                spot_bbx = temperature_filter(temperature, expanded_mask, spot_bbx, temperature_res, sensor)

            view_and_save(raw_img, mask_img, expanded_mask, spot_bbx, line_bbx, flo_bbx, strip_bbx, facet_bbx, group_bbx,
                          if_view=False, if_save=True,
                          save_dir=save_path, save_name=fn.split('/')[-1],
                          sensor=sensor)

            spot_cnt += len(spot_bbx)
            line_cnt += len(line_bbx)
            flo_cnt += len(flo_bbx)
            facet_cnt += len(facet_bbx)
            group_cnt += len(group_bbx)
            strip_cnt += len(strip_bbx)

            spot_cnt_per.append(len(spot_bbx))
            line_cnt_per.append(len(line_bbx))
            flo_cnt_per.append(len(flo_bbx))
            facet_cnt_per.append(len(facet_bbx))
            group_cnt_per.append(len(group_bbx))
            strip_cnt_per.append(len(strip_bbx))

            spot_bbx_rec.append(spot_bbx)
            line_bbx_rec.append(line_bbx)
            flo_bbx_rec.append(flo_bbx)
            strip_bbx_rec.append(strip_bbx)
            facet_bbx_rec.append(facet_bbx)
            group_bbx_rec.append(group_bbx)

            img_name_rec.append(fn)

    dst = time.time()
    print('Overall running time: {}s, {}s per image.'
          .format(dst - start, (dst - start) / len(in_files)))
    print('Preprocess time {}s, segment time {}s, detect time {}s per image'.
          format(time_recoder['preprocess'].mean()/volume,
                 time_recoder['seg'].mean()/volume,
                 time_recoder['detect'].mean()))
    # print('Overall running time: {}s, {}s per image.'
    #       .format(np.sum(time_list), (np.sum(time_list)) / len(in_files)))
    one_type_p, one_type_r, group_p, group_r = evaluate_pr(file_path, img_name_rec,
                                                           spot_bbx_rec, line_bbx_rec,
                                                           flo_bbx_rec, strip_bbx_rec,
                                                           facet_bbx_rec, group_bbx_rec)
    print('Group precision: {}, recall: {}'.format(group_p, group_r))
    print('Others precision: {}, recall: {}'.format(one_type_p, one_type_r))

    return in_files, spot_cnt, line_cnt, flo_cnt, facet_cnt, group_cnt, strip_cnt, \
           spot_cnt_per, line_cnt_per, flo_cnt_per, facet_cnt_per, group_cnt_per, strip_cnt_per


if __name__ == "__main__":
    # panels_predict(file_path='C:/Users/MSI/Desktop/data/xt2/',
    #                save_path='C:/Users/MSI/Desktop/data/xt2/out/',
    #                volume=1, sea_flag=True, h20t_flag=False, xt2_flag=True)
    # panels_predict(file_path='C:/Users/MSI/Desktop/data/h20t/',
    #                save_path='C:/Users/MSI/Desktop/data/h20t/out/',
    #                volume=1, sea_flag=True, h20t_flag=True, xt2_flag=False)
    # panels_predict(file_path='F:/zhengtai2stage/non_spot/img1_cutting1101/changxing_1/',
    #                save_path='F:/zhengtai2stage/non_spot/img1_cutting1101/changxing_1/out/',
    #                volume=1, sea_flag=True, h20t_flag=False, xt2_flag=True)
    # panels_predict(file_path='F:/zhengtai2stage/non_spot/yiqi/beitashan/',
    #                save_path='F:/zhengtai2stage/non_spot/yiqi/beitashan/out/',  # 北塔山50MW光伏电站
    #                volume=1, sea_flag=True, h20t_flag=False, xt2_flag=True)
    # panels_predict(file_path='C:/Users/MSI/Desktop/data/h20t/',save_path='C:/Users/MSI/Desktop/data/h20t/out2/',
    #                volume=1,  temperature_res = 8, sea_flag=True, h20t_flag=True, xt2_flag=False)
    panels_predict(file_path='C:/Users/xcq/Desktop/xt_2/',
                   save_path='C:/Users/xcq/Desktop/xt_2/output/',
                   volume=10, temperature_res = 1, sea_flag=True, h20t_flag=False, xt2_flag=True)
    # panels_predict(file_path='C:/Users/MSI/Desktop/data/xt2/original/',
    #                save_path='C:/Users/MSI/Desktop/data/xt2/original/out1/',
    #                volume=3, temperature_res = 1, sea_flag=True, h20t_flag=False, xt2_flag=True)

    os._exit(0)
