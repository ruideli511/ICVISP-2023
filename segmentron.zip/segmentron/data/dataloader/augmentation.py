from PIL import Image, ImageFilter
import numpy as np

def unevenLightCompensate(img, blockSize):
    def _process_gray_img(gray):
        gray2 = np.array(gray, dtype='float32')
        average = np.mean(gray2)
        rows_new = int(np.ceil(gray.size[0] / blockSize))
        cols_new = int(np.ceil(gray.size[1] / blockSize))
        blockImage = np.zeros((rows_new, cols_new), dtype=np.float32)
        for r in range(rows_new):
            for c in range(cols_new):
                rowmin = r * blockSize
                rowmax = (r + 1) * blockSize
                if (rowmax > gray.size[0]):
                    rowmax = gray.size[0]
                colmin = c * blockSize
                colmax = (c + 1) * blockSize
                if (colmax > gray.size[1]):
                    colmax = gray.size[1]
                imageROI = gray2[rowmin:rowmax, colmin:colmax]
                temaver = np.mean(imageROI)

                blockImage[r, c] = temaver

        blockImage = blockImage - average
        blockImage2 = Image.fromarray(blockImage).resize((gray.size[1], gray.size[0]), Image.BICUBIC)
        dst = gray2 - np.array(blockImage2).transpose()
        dst[dst > 255] = 255
        dst[dst < 0] = 0
        dst = Image.fromarray(dst.astype(np.uint8))
        dst = dst.filter(ImageFilter.GaussianBlur(3))
        # dst = cv2.cvtColor(dst, cv2.COLOR_GRAY2BGR)
        return dst
    # gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if len(img.getbands()) > 1:
        r, g, b = img.split()
        r = _process_gray_img(r)
        g = _process_gray_img(g)
        b = _process_gray_img(b)
        return Image.merge('RGB', [r, g, b])
    else:
        return _process_gray_img(img)
