"""Pascal ADE20K Semantic Segmentation Dataset."""
import json
import math
import os
import logging
import torch
import numpy as np

from PIL import Image, ImageDraw, ImageOps
from .seg_data_base import SegmentationDataset
from .augmentation import unevenLightCompensate
from ...config import cfg


class PVSegmentation(SegmentationDataset):
    """User-defined Photovoltaic Segmentation Dataset.

    Parameters
    ----------
    root : string
        Path to PV dataset folder. Default is './datasets/pv'
    split: string
        'train', 'val' or 'test'
    transform : callable, optional
        A function that transforms the image
    Examples
    --------
    >>> from torchvision import transforms
    >>> import torch.utils.data as data
    >>> # Transforms for Normalization
    >>> input_transform = transforms.Compose([
    >>>     transforms.ToTensor(),
    >>>     transforms.Normalize((.485, .456, .406), (.229, .224, .225)),
    >>> ])
    >>> # Create Dataset
    >>> trainset = PVSegmentation(split='train', transform=input_transform)
    >>> # Create Training Loader
    >>> train_data = data.DataLoader(
    >>>     trainset, 4, shuffle=True,
    >>>     num_workers=4)
    """
    BASE_DIR = 'ZhengTai2DataSet'
    NUM_CLASS = 2

    def __init__(self, root='pv_ir', split='train', mode=None, transform=None, crop_size=None, **kwargs):
        super(PVSegmentation, self).__init__(root, split, mode, transform, **kwargs)
        # local runs
        root = cfg.DATASET.PATH + root
        root = os.path.join(root, self.BASE_DIR)
        if cfg.DATASET.SENSOR == 'xt2':
            root = 'C:/Users/xcq/Desktop/xt2_img'
        assert os.path.exists(root), "Please put the data in {SEG_ROOT}/datasets/pv_ir."
        self.images, self.masks = _get_pv_pairs(root, split, mode)
        if len(self.images) == 0:
            raise RuntimeError("Found 0 images in subfolders of:" + root + "\n")
        logging.info('Found {} images in the folder {}'.format(len(self.images), root))

    def __getitem__(self, index):
        if cfg.DATASET.NAME == 'pv_ir':
            if cfg.DATASET.SENSOR == 'xt2' or self.images[index].endswith('R.JPG'):
                img = Image.open(self.images[index])
                if img.layers == 3:
                    img, _, _ = img.split()
            else:
                dji_irpAddress = cfg.ROOT_PATH + '/segmentron/release_x86/dji_irp.exe'
                out_address = self.images[index][:-4] + ".raw"
                if not os.path.exists(out_address):
                    cmd = dji_irpAddress + " -s " + self.images[index] + \
                          " -a process -o " + out_address + " -p white_hot"
                    process = os.popen(cmd)
                    process.read()
                img = np.fromfile(out_address, dtype='uint8')
                img = Image.fromarray(img.reshape(512, 640, 3))
                img, _, _ = img.split()
            # xt2 images
        else:
            img = Image.open(self.images[index]).convert('RGB')
            # img = unevenLightCompensate(img, 8)
        # print(self.images[index])
        if self.mode != 'test':
            mask = _get_mask_from_json(self.masks[index], img.size)
        # synchrosized transform
        if self.mode == 'train':
            img, mask = self._sync_transform(img, mask)
        elif self.mode == 'val':
            img, mask = self._val_sync_transform(img, mask)
        else:
            assert self.mode in ['test', 'testval']
            if cfg.DATASET.SENSOR == 'xt2':
                img = img.crop((25,45,600,475))
            if cfg.TRAIN.BASE_SIZE is not None:
                img = self._test_img_transform(img, type='image')
                if self.mode == 'testval':
                    mask = self._test_img_transform(mask, type='mask')
                    mask = self._mask_transform(mask)
                else:
                    mask = torch.zeros(img.size, dtype=torch.long)

        # general resize, normalize and to Tensor
        if self.transform is not None:
            img = self.transform(img)
        return img, mask, self.images[index]

    def _mask_transform(self, mask):
        return torch.LongTensor(np.array(mask).astype('int32'))

    def _test_img_transform(self, img, type='image'):
        w, h = img.size
        if w > h:
            oh = cfg.TRAIN.BASE_SIZE
            ow = int(1.0 * w * oh / h)
        else:
            ow = cfg.TRAIN.BASE_SIZE
            oh = int(1.0 * h * ow / w)
        if type == 'image':
            img = img.resize((ow, oh), Image.BILINEAR)
        elif type == 'mask':
            img = img.resize((ow, oh), Image.NEAREST)
        # Assure the image height and weight are divisible by unet output stride 32
        if cfg.MODEL.MODEL_NAME.lower() == 'unet' and \
                (oh % 32 != 0 or ow % 32 != 0):
            padh = (32 * (oh // 32 + (oh % 32 != 0))) - oh
            padw = (32 * (ow // 32 + (ow % 32 != 0))) - ow
            img = ImageOps.expand(img, border=(0, 0, padw, padh), fill=0)
        return img

    def __len__(self):
        return len(self.images)

    @property
    def pred_offset(self):
        return 1

    @property
    def classes(self):
        """Category names."""
        return ("background", "foreground")

def _get_pv_pairs(folder, split='train', mode='train'):
    img_paths = []
    mask_paths = []
    if mode == 'test':
        img_folder = os.path.join(folder, 'images/test')
    elif split == 'train':
        img_folder = os.path.join(folder, 'images/train')
        mask_folder = os.path.join(folder, 'annotations/train')
    elif split == 'val':
        img_folder = os.path.join(folder, 'images/val')
        mask_folder = os.path.join(folder, 'annotations/val')
    else:
        img_folder = os.path.join(folder, 'images/testval')
        mask_folder = os.path.join(folder, 'annotations/testval')
    for filename in os.listdir(img_folder):
        basename, _ = os.path.splitext(filename)
        if filename.endswith(".JPG"):
            imgpath = os.path.join(img_folder, filename)
            if os.path.isfile(imgpath):
                img_paths.append(imgpath)
            if mode != 'test':
                maskname = basename + '.json'
                maskpath = os.path.join(mask_folder, maskname)
                if os.path.isfile(maskpath):
                    mask_paths.append(maskpath)
                else:
                    logging.info('cannot find the mask:', maskpath)

    return img_paths, mask_paths

def _get_mask_from_json(json_path, img_shape):
    mask = Image.new('L', img_shape, 0)
    with open(json_path, 'r', encoding='gbk') as f:
        try:
            polygons = json.load(f)['shapes']
        except UnicodeDecodeError as e:
            f = open(json_path, 'r', encoding='utf-8')
            polygons = json.load(f)['shapes']
    for polygon in polygons:
        points = polygon['points']
        points = [tuple([math.floor(pt1) for pt1 in pt]) for pt in points]
        ImageDraw.Draw(mask).polygon(points, fill=1)
    return mask

def getStat(train_data):
    '''
    Compute mean and variance for training data
    :param train_data: 自定义类Dataset(或ImageFolder即可)
    :return: (mean, std)
    '''
    print('Compute mean and variance for training data.')
    print(len(train_data))
    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=1, shuffle=False, num_workers=0,
        pin_memory=True)
    mean = torch.zeros(3)
    std = torch.zeros(3)
    for X, _, _ in train_loader:
        for d in range(3):
            mean[d] += X[:, d, :, :].numpy().mean()
            std[d] += X[:, d, :, :].numpy().std()
    mean.div_(len(train_data))
    std.div_(len(train_data))
    return list(mean.numpy()), list(std.numpy())

def margin_removal(img):
    img[:25, :] = 0
    img[475:, :] = 0
    img[:, :25] = 0
    img[:, 600:] = 0
    return img

if __name__ == '__main__':
    train_dataset = PVSegmentation()

