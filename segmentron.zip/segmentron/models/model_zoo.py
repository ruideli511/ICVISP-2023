import logging
import torch

from collections import OrderedDict
from segmentron.utils.registry import Registry
from .auxunet import Unet
# import segmentation_models_pytorch as smp
from ..config import cfg

MODEL_REGISTRY = Registry("MODEL")
MODEL_REGISTRY.__doc__ = """
Registry for segment model, i.e. the whole model.

The registered object will be called with `obj()`
and expected to return a `nn.Module` object.
"""


def get_segmentation_model():
    """
    Built the whole model, defined by `cfg.MODEL.META_ARCHITECTURE`.
    """
    model_name = cfg.MODEL.MODEL_NAME
    if model_name.lower() == 'unet':
        in_channels = 1 if cfg.DATASET.NAME == 'pv_ir' else 3
        mcf_attention = True if cfg.MODEL.MCF_ATTENTION else False
        model = Unet(
                            encoder_name="efficientnet-b7",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
                            encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
                            in_channels=in_channels,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
                            classes=2,  # model output channels (number of classes in your dataset)
                            use_aux_loss=cfg.SOLVER.AUX,
                            mcf_attention=mcf_attention,
                        )
    else:
        model = MODEL_REGISTRY.get(model_name)()
    load_model_pretrain(model)
    return model


def load_model_pretrain(model):
    if cfg.PHASE == 'train':
        if cfg.TRAIN.PRETRAINED_MODEL_PATH:
            logging.info('load pretrained model from {}'.format(cfg.TRAIN.PRETRAINED_MODEL_PATH))
            state_dict_to_load = torch.load(cfg.TRAIN.PRETRAINED_MODEL_PATH)
            keys_wrong_shape = []
            state_dict_suitable = OrderedDict()
            state_dict = model.state_dict()
            for k, v in state_dict_to_load.items():
                if 'head.block.2' not in k:
                    if v.shape == state_dict[k].shape:
                        state_dict_suitable[k] = v
                    else:
                        keys_wrong_shape.append(k)
            logging.info('Shape unmatched weights: {}'.format(keys_wrong_shape))
            msg = model.load_state_dict(state_dict_suitable, strict=False)
            logging.info(msg)
    else:
        if cfg.TEST.TEST_MODEL_PATH:
            logging.info('load test model from {}'.format(cfg.TEST.TEST_MODEL_PATH))
            if cfg.TEST.TEST_MODEL_PATH.endswith('best_model.pth'):
                msg = model.load_state_dict(torch.load(cfg.TEST.TEST_MODEL_PATH), strict=False)
            else:
                msg = model.load_state_dict(torch.load(cfg.TEST.TEST_MODEL_PATH)['state_dict'], strict=False)
            logging.info(msg)