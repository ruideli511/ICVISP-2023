from .config import SegmentronConfig

cfg = SegmentronConfig()
config_file = 'C:/Users/xcq/PycharmProjects/SegmenTron-master/configs/pv_unet.yaml'
# config_file = '/data/code/xcq/SegmenTron-master/configs/pv_unet_dist.yaml'
cfg.ROOT_PATH = 'C:/Users/xcq/PycharmProjects/SegmenTron-master'
# cfg.ROOT_PATH = '/data/code/xcq/SegmenTron-master'
########################## basic set ###########################################
# random seed
cfg.SEED = 1024
# train time stamp, auto generate, do not need to set
cfg.TIME_STAMP = ''
# root path

# model phase ['train', 'test']
cfg.PHASE = 'test'

########################## dataset config #########################################
# senosrs
cfg.DATASET.SENSOR = 'h20t'
# dataset name and path
cfg.DATASET.NAME = 'pv_ir'
cfg.DATASET.PATH = ''
# pixel mean and std
cfg.DATASET.MEAN = [0.46332175, 0.49105614, 0.5243472]  # RGB images
cfg.DATASET.STD = [0.21419723, 0.19821909, 0.17914988]
# cfg.DATASET.MEAN = [0.72953373, 0.27358314, 0.24029718] # infrared images
# cfg.DATASET.STD = [0.2895478, 0.26329616, 0.20832938]
# dataset ignore index
cfg.DATASET.IGNORE_INDEX = -1
# workers
cfg.DATASET.WORKERS = 8
# val dataset mode
cfg.DATASET.MODE = 'testval'
########################### data augment ######################################
# data augment image rotation
cfg.AUG.ROTATION = True
# blur probability
cfg.AUG.BLUR_PROB = 0.0
# blur radius
cfg.AUG.BLUR_RADIUS = 0.0
# color jitter, float or tuple: (0.1, 0.2, 0.3, 0.4)
cfg.AUG.COLOR_JITTER = None
# random grayscale
cfg.AUG.GRAYSCALE = False
########################### train config ##########################################
# epochs
cfg.TRAIN.EPOCHS = 50
# batch size
cfg.TRAIN.BATCH_SIZE = 2
# train crop size
cfg.TRAIN.CROP_SIZE = (480, 480)
# train base size
cfg.TRAIN.BASE_SIZE = 512
# model output dir
cfg.TRAIN.MODEL_SAVE_DIR = 'runs/checkpoints/'
# log dir
cfg.TRAIN.LOG_SAVE_DIR = 'runs/logs/'
# pretrained model for eval or finetune
cfg.TRAIN.PRETRAINED_MODEL_PATH = ''
# use pretrained backbone model over imagenet`
cfg.TRAIN.BACKBONE_PRETRAINED = True
# backbone pretrained model path, if not specific, will load from url when backbone pretrained enabled
cfg.TRAIN.BACKBONE_PRETRAINED_PATH = ''
# resume model path
cfg.TRAIN.RESUME_MODEL_PATH = ''
# whether to use synchronize bn
cfg.TRAIN.SYNC_BATCH_NORM = False
# save model every checkpoint-epoch
cfg.TRAIN.SNAPSHOT_EPOCH = 10

########################### optimizer config ##################################
# base learning rate
cfg.SOLVER.LR = 0.0025
# optimizer method
cfg.SOLVER.OPTIMIZER = "adam"
# optimizer epsilon
cfg.SOLVER.EPSILON = 1e-8
# optimizer momentum
cfg.SOLVER.MOMENTUM = 0.9
# weight decay
cfg.SOLVER.WEIGHT_DECAY = 1e-4 #0.00004
# decoder lr x10
cfg.SOLVER.DECODER_LR_FACTOR = 10.0
# lr scheduler mode
cfg.SOLVER.LR_SCHEDULER = "poly"
# poly power
cfg.SOLVER.POLY.POWER = 0.9
# step gamma
cfg.SOLVER.STEP.GAMMA = 0.1
# milestone of step lr scheduler
cfg.SOLVER.STEP.DECAY_EPOCH = [10, 20]
# warm up epochs can be float
cfg.SOLVER.WARMUP.EPOCHS = 0.
# warm up factor
cfg.SOLVER.WARMUP.FACTOR = 1.0 / 3
# warm up method
cfg.SOLVER.WARMUP.METHOD = 'linear'
# whether to use ohem
cfg.SOLVER.OHEM = False
# whether to use aux loss
cfg.SOLVER.AUX = False
# aux loss weight
cfg.SOLVER.AUX_WEIGHT = 0.2
# loss name
cfg.SOLVER.LOSS_NAME = ''
########################## test config ###########################################
# val/test model path
cfg.TEST.TEST_MODEL_PATH = ''
# save local masks
cfg.TEST.SAVED = False
# test batch size
cfg.TEST.BATCH_SIZE = 2
# eval crop size
cfg.TEST.CROP_SIZE = None  # IR images
# multiscale eval
cfg.TEST.SCALES = [1.0]
# flip
cfg.TEST.FLIP = False

########################## visual config ###########################################
# visual result output dir
cfg.VISUAL.OUTPUT_DIR = '../runs/visual/masks'

########################## model #######################################
# model name
cfg.MODEL.MODEL_NAME = 'UNet'
# model backbone
cfg.MODEL.BACKBONE = ''
# model backbone channel scale
cfg.MODEL.BACKBONE_SCALE = 1.0
# support resnet b, c. b is standard resnet in pytorch official repo
# cfg.MODEL.RESNET_VARIANT = 'b'
# multi branch loss weight
cfg.MODEL.MULTI_LOSS_WEIGHT = [1.0]
# gn groups
cfg.MODEL.DEFAULT_GROUP_NUMBER = 32
# whole model default epsilon
cfg.MODEL.DEFAULT_EPSILON = 1e-5
# batch norm, support ['BN', 'SyncBN', 'FrozenBN', 'GN', 'nnSyncBN']
cfg.MODEL.BN_TYPE = 'BN'
# batch norm epsilon for encoder, if set None will use api default value.
cfg.MODEL.BN_EPS_FOR_ENCODER = 1e-3
# batch norm epsilon for encoder, if set None will use api default value.
cfg.MODEL.BN_EPS_FOR_DECODER = None
# backbone output stride
cfg.MODEL.OUTPUT_STRIDE = 16
# BatchNorm momentum, if set None will use api default value.
cfg.MODEL.BN_MOMENTUM = None

cfg.MODEL.MCF_ATTENTION = False

########################## DANet config ####################################
# danet param
cfg.MODEL.DANET.MULTI_DILATION = None
# danet param
cfg.MODEL.DANET.MULTI_GRID = False

########################## DeepLab config ####################################
# whether to use aspp
cfg.MODEL.DEEPLABV3_PLUS.USE_ASPP = True
# whether to use decoder
cfg.MODEL.DEEPLABV3_PLUS.ENABLE_DECODER = True
# whether aspp use sep conv
cfg.MODEL.DEEPLABV3_PLUS.ASPP_WITH_SEP_CONV = True
# whether decoder use sep conv
cfg.MODEL.DEEPLABV3_PLUS.DECODER_USE_SEP_CONV = True

########################## UNET config #######################################
# upsample mode
# cfg.MODEL.UNET.UPSAMPLE_MODE = 'bilinear'

########################## OCNet config ######################################
# ['base', 'pyramid', 'asp']
cfg.MODEL.OCNet.OC_ARCH = 'base'

########################## EncNet config ######################################
cfg.MODEL.ENCNET.SE_LOSS = True
cfg.MODEL.ENCNET.SE_WEIGHT = 0.2
cfg.MODEL.ENCNET.LATERAL = True


########################## CCNET config ######################################
cfg.MODEL.CCNET.RECURRENCE = 2

########################## CGNET config ######################################
cfg.MODEL.CGNET.STAGE2_BLOCK_NUM = 3
cfg.MODEL.CGNET.STAGE3_BLOCK_NUM = 21

########################## PointRend config ##################################
cfg.MODEL.POINTREND.BASEMODEL = 'DeepLabV3_Plus'

########################## hrnet config ######################################
cfg.MODEL.HRNET.PRETRAINED_LAYERS = ['*']
cfg.MODEL.HRNET.STEM_INPLANES = 64
cfg.MODEL.HRNET.FINAL_CONV_KERNEL = 1
cfg.MODEL.HRNET.WITH_HEAD = True
# stage 1
cfg.MODEL.HRNET.STAGE1.NUM_MODULES = 1
cfg.MODEL.HRNET.STAGE1.NUM_BRANCHES = 1
cfg.MODEL.HRNET.STAGE1.NUM_BLOCKS = [1]
cfg.MODEL.HRNET.STAGE1.NUM_CHANNELS = [32]
cfg.MODEL.HRNET.STAGE1.BLOCK = 'BOTTLENECK'
cfg.MODEL.HRNET.STAGE1.FUSE_METHOD = 'SUM'
# stage 2
cfg.MODEL.HRNET.STAGE2.NUM_MODULES = 1
cfg.MODEL.HRNET.STAGE2.NUM_BRANCHES = 2
cfg.MODEL.HRNET.STAGE2.NUM_BLOCKS = [4, 4]
cfg.MODEL.HRNET.STAGE2.NUM_CHANNELS = [32, 64]
cfg.MODEL.HRNET.STAGE2.BLOCK = 'BASIC'
cfg.MODEL.HRNET.STAGE2.FUSE_METHOD = 'SUM'
# stage 3
cfg.MODEL.HRNET.STAGE3.NUM_MODULES = 1
cfg.MODEL.HRNET.STAGE3.NUM_BRANCHES = 3
cfg.MODEL.HRNET.STAGE3.NUM_BLOCKS = [4, 4, 4]
cfg.MODEL.HRNET.STAGE3.NUM_CHANNELS = [32, 64, 128]
cfg.MODEL.HRNET.STAGE3.BLOCK = 'BASIC'
cfg.MODEL.HRNET.STAGE3.FUSE_METHOD = 'SUM'
# stage 4
cfg.MODEL.HRNET.STAGE4.NUM_MODULES = 1
cfg.MODEL.HRNET.STAGE4.NUM_BRANCHES = 4
cfg.MODEL.HRNET.STAGE4.NUM_BLOCKS = [4, 4, 4, 4]
cfg.MODEL.HRNET.STAGE4.NUM_CHANNELS = [32, 64, 128, 256]
cfg.MODEL.HRNET.STAGE4.BLOCK = 'BASIC'
cfg.MODEL.HRNET.STAGE4.FUSE_METHOD = 'SUM'

cfg.update_from_file(config_file)
