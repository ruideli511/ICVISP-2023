'''
评估检测结果，召回率和检出率
'''

import os


def isInterArea(testPoint,AreaPoint):  # testPoint为待测点[x,y]
    LBPoint = AreaPoint[0]  # AreaPoint为按顺时针顺序的4个点[[x1,y1],[x2,y2],[x3,y3],[x4,y4]]
    LTPoint = AreaPoint[1]
    RTPoint = AreaPoint[2]
    RBPoint = AreaPoint[3]
    a = (LTPoint[0]-LBPoint[0])*(testPoint[1]-LBPoint[1])-(LTPoint[1]-LBPoint[1])*(testPoint[0]-LBPoint[0])
    b = (RTPoint[0]-LTPoint[0])*(testPoint[1]-LTPoint[1])-(RTPoint[1]-LTPoint[1])*(testPoint[0]-LTPoint[0])
    c = (RBPoint[0]-RTPoint[0])*(testPoint[1]-RTPoint[1])-(RBPoint[1]-RTPoint[1])*(testPoint[0]-RTPoint[0])
    d = (LBPoint[0]-RBPoint[0])*(testPoint[1]-RBPoint[1])-(LBPoint[1]-RBPoint[1])*(testPoint[0]-RBPoint[0])
    # print(a,b,c,d)
    if (a>0 and b>0 and c>0 and d>0) or (a<0 and b<0 and c<0 and d<0):
        return True
    else:
        return False

def form_gt_format(gt_str_arr):
    legal_gt_arr = []
    label_arr = []
    for gt_str in gt_str_arr:
        gt_str = gt_str.strip('\n').split(',')
        if len(gt_str) == 9 or len(gt_str) == 5:
            if len(gt_str) == 9:
                x1, y1, x2, y2, x3, y3, x4, y4, label = float(gt_str[0]), float(gt_str[1]), \
                                                        float(gt_str[2]), float(gt_str[3]), \
                                                        float(gt_str[4]), float(gt_str[5]), \
                                                        float(gt_str[6]), float(gt_str[7]), \
                                                        gt_str[8]
            elif len(gt_str) == 5:
                x1, y1, x2, y2, x3, y3, x4, y4, label = float(gt_str[0]), float(gt_str[1]), \
                                                        float(gt_str[2]), float(gt_str[1]), \
                                                        float(gt_str[2]), float(gt_str[3]), \
                                                        float(gt_str[0]), float(gt_str[3]), \
                                                        gt_str[4]
            legal_gt_arr.append([[x1, y1], [x2, y2], [x3, y3], [x4, y4]])
            label_arr.append(label)
    return legal_gt_arr, label_arr

def evaluate_pr(file_path, img_name_rec, spot_bbx_rec, line_bbx_rec, flo_bbx_rec,
             strip_bbx_rec, facet_bbx_rec, group_bbx_rec):
    gt_path = file_path[:-1] + '_txt\\'
    pos_cnt_dict, neg_cnt_dict, gt_num_dict = {'as_one_type': 0, 'group': 0}, \
                                              {'as_one_type': 0, 'group': 0}, \
                                              {'as_one_type': 0, 'group': 0}
    one_type_p, one_type_r, group_p, group_r = 0, 0, 0, 0
    if os.path.exists(gt_path):
        for k, img_name in enumerate(img_name_rec):
            txt_path = gt_path + img_name[:-4] + '.txt'
            if os.path.exists(txt_path):
                f = open(txt_path, "r")   # 设置文件对象
                gt_str = f.readlines()  # 直接将文件中按行读到list里，效果与方法2一样
                f.close()             # 关闭文件

                gt_arr, label_arr = form_gt_format(gt_str)
                spot_bbx, line_bbx, flo_bbx, strip_bbx, facet_bbx, group_bbx = \
                    spot_bbx_rec[k], line_bbx_rec[k], flo_bbx_rec[k], \
                    strip_bbx_rec[k], facet_bbx_rec[k], group_bbx_rec[k]
                as_one_type = spot_bbx + line_bbx + flo_bbx + strip_bbx + facet_bbx  # 当作同一类型
                as_one_type_pos_cnt = 0

                while len(gt_arr) > 0:  # 判断全部ground truth
                    gt, label = gt_arr.pop(), label_arr.pop()
                    label = 'as_one_type' if label != 'group' else label  # 当作同一类型
                    gt_num_dict[label] = 0 if label not in gt_num_dict else gt_num_dict[label] + 1
                    if len(as_one_type) > 0 and label != 'group':
                        for one_bbx in as_one_type:
                            x0, y0 = one_bbx[0] + one_bbx[2] / 2, one_bbx[1] + one_bbx[3] / 2
                            if isInterArea([x0, y0], gt):
                                pos_cnt_dict[label] = 0 if label not in pos_cnt_dict else pos_cnt_dict[label] + 1
                                as_one_type_pos_cnt += 1
                        neg_cnt_dict['as_one_type'] += len(as_one_type) - as_one_type_pos_cnt

                    if label == 'group':
                        for one_bbx in group_bbx:
                            x0, y0 = one_bbx[0] + one_bbx[2] / 2, one_bbx[1] + one_bbx[3] / 2
                            if isInterArea([x0, y0], gt):
                                pos_cnt_dict[label] = 0 if label not in pos_cnt_dict else pos_cnt_dict[label] + 1
                        neg_cnt_dict[label] += len(as_one_type) - as_one_type_pos_cnt
        try:
            one_type_p = pos_cnt_dict['as_one_type'] / (pos_cnt_dict['as_one_type'] + neg_cnt_dict['as_one_type'])
            one_type_r = pos_cnt_dict['as_one_type'] / gt_num_dict['as_one_type']
            group_p = pos_cnt_dict['group'] / (pos_cnt_dict['group'] + neg_cnt_dict['group'])
            group_r = pos_cnt_dict['group'] / gt_num_dict['group']
        except ZeroDivisionError:
            print('division by zero')
    return one_type_p, one_type_r, group_p, group_r