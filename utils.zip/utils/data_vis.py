# import matplotlib.pyplot as plt
import cv2
import os
import numpy as np
from PIL import Image
from imageutils.shape_detection import rotate_rectangle

# def plot_img_and_mask(img, mask):
#     classes = mask.shape[2] if len(mask.shape) > 2 else 1
#     fig, ax = plt.subplots(1, classes + 1)
#     ax[0].set_title('Input image')
#     ax[0].imshow(img)
#     if classes > 1:
#         for i in range(classes):
#             ax[i+1].set_title(f'Output mask (class {i+1})')
#             ax[i+1].imshow(mask[:, :, i])
#     else:
#         ax[1].set_title(f'Output mask')
#         ax[1].imshow(mask)
#     plt.xticks([]), plt.yticks([])
#     plt.show()


def draw_polygon(image, pts, colour=(0, 0, 255), thickness=2):
    """
    Draws a rectangle on a given image.
    :param image: What to draw the rectangle on
    :param pts: Array of point objects
    :param colour: Colour of the rectangle edges
    :param thickness: Thickness of the rectangle edges
    :return: Image with a rectangle
    """
    for i in range(0, len(pts)):
        n = (i + 1) if (i + 1) < len(pts) else 0                 # 0->1 , 1->2, ..., n-2->n-1, n-1->0
        cv2.line(image, (pts[i][0], pts[i][1]), (pts[n][0], pts[n][1]), colour, thickness)        # 线段起点，终点绘制直线

    return image


def rge2gray(img):
    def whiten(component):
        component = (component - np.mean(component)) / np.std(component)
        component = cv2.normalize(component, dst=None, alpha=255, beta=0,
                                  norm_type=cv2.NORM_MINMAX) / 255  # dst-与component大小相同的输出数组,规范化值0-255,NORM_MINMAX:数组的数值被平移或缩放到一个指定的范围，线性归一化。
        return np.power(component, 2)

    r, g, b = img.split()
    r, g, b = whiten(r), whiten(g), whiten(b)
    new_img = ((r + g + b) / 3 * 255).astype('uint8')
    return Image.fromarray(new_img, 'L')  # channel=1

def view_and_save(img, mask_img, expanded_mask, spot_bbx, line_bbx, flo_bbx, strip_bbx, facet_bbx, group_bbx,
                  if_view=True, if_save=False, save_dir='', save_name='', sensor='h20t'):
    bbxs = [(spot_bbx, '1'), (line_bbx, '2'), (flo_bbx, '3'),
            (strip_bbx, '4'), (facet_bbx, '5'), (group_bbx, '6')]
    colored_img = cv2.applyColorMap(img, cv2.COLORMAP_BONE)  # 伪彩色函数
    # if sensor == 'xt2':
    #     colored_img = draw_polygon(colored_img, [[24, 24], [599, 24], [599, 474], [24, 474]], colour=(255, 255, 255))
    for bbx, flaw_type in bbxs:
        if bbx:
            for bx in bbx:
                x, y, w, h, angle = bx
                x, y = max(x, 0), max(y, 0)
                if flaw_type in ['6']:  # '1','2','3','4','5',
                    rotated_vertex = rotate_rectangle(x, y, w, h, angle=angle)
                    colored_img = draw_polygon(colored_img, rotated_vertex)
                # cv2.rectangle(img, (x1, y1), (x2, y2), (255, 0, 0), thickness=2)
                cv2.putText(colored_img, flaw_type, (x, y), cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 0, 255),
                            thickness=1)  # 图片,添加的文字,左上角坐标,字体,字体大小,颜色,字体粗细
    if if_save:
        if not os.path.exists(save_dir):  # 如果 save_dir 存在，返回 True；如果 save_dir 不存在，返回 False。
            os.mkdir(save_dir)
        if not os.path.exists(save_dir[:-1] + '_mask\\'):  # 如果 save_dir_mask 存在，返回 True；如果 save_dir_mask 不存在，返回 False。
            os.mkdir(save_dir[:-1] + '_mask\\')
        # if not os.path.exists(save_dir[:-1] + 'expanded_mask\\'):  # 如果 save_dir_mask 存在，返回 True；如果 save_dir_mask 不存在，返回 False。
        #     os.mkdir(save_dir[:-1] + 'expanded_mask\\')
        cv2.imencode(".jpg", mask_img)[1].tofile(save_dir[:-1] + '_mask\\' + save_name)
        # cv2.imencode(".jpg", expanded_mask)[1].tofile(save_dir[:-1] + '_expanded_mask\\' + save_name)
        cv2.imencode(".jpg", colored_img)[1].tofile(save_dir + save_name)
    if if_view:
        cv2.imshow(save_name, colored_img)