import os
import random
import shutil
from shutil import copy2

"""os.listdir会将文件夹下的文件名集合成一个列表并返回"""


def getDir(filepath):
    pathlist = os.listdir(filepath)
    return pathlist

def empty_dir(dir_path):
    if os.listdir(dir_path) != []:
        for root, dirs, files in os.walk(dir_path, topdown=False):
            # 第一步：删除文件
            for name in files:
                os.remove(os.path.join(root, name))  # 删除文件

"""制作五类图像总的训练集，验证集和测试集所需要的文件夹，例如训练集的文件夹中装有五个文件夹，这些文件夹分别装有一定比例的五类图像"""


def mkTotalDir(data_path):
    img_path = data_path + 'images/'
    json_path = data_path + 'annotations/'
    dic = ['train', 'val', 'testval']
    for i in range(0, 3):
        current_img_path = img_path + dic[i] + '/'
        current_json_path = json_path + dic[i] + '/'
        # 这个函数用来判断当前路径是否存在，如果存在则创建失败，如果不存在则可以成功创建
        isImgExists = os.path.exists(current_img_path)
        isJsonExists = os.path.exists(current_json_path)
        if not isImgExists:
            os.makedirs(current_img_path)
            print('image successful ' + dic[i])
        else:
            print('is existed')
        if not isJsonExists:
            os.makedirs(current_json_path)
            print('json successful ' + dic[i])
        else:
            print('is existed')
    return


"""传入的参数是n类图像原本的路径，返回的是这个路径下各类图像的名称列表和图像的类别数"""


def getClassesMes(source_path):
    classes_name_list = getDir(source_path)
    classes_num = len(classes_name_list)
    return classes_name_list, classes_num


"""change_path其实就是制作好的n类图像总的训练集，验证集和测试集的路径，sourcepath和上面一个函数相同
这个函数是用来建训练集，测试集，验证集下五类图像的文件夹，就是建15个文件夹，当然也可以建很多类
"""


def mkClassDir(source_path, change_path):
    classes_name_list, classes_num = getClassesMes(source_path)
    for i in range(0, classes_num):
        current_class_path = os.path.join(change_path, classes_name_list[i])
        isExists = os.path.exists(current_class_path)
        if not isExists:
            os.makedirs(current_class_path)
            print('successful ' + classes_name_list[i])
        else:
            print('is existed')


# source_path:原始多类图像的存放路径
# train_path:训练集图像的存放路径
# validation_path:验证集图像的存放路径D:\RSdata_dir\NWPU-RESISC45\\
# test_path:测试集图像的存放路径


def divideTrainValidationTest(source_path, split_ratio=[0.8, 0.1, 0.1]):
    """先获取五类图像的名称列表和类别数目"""
    # classes_name_list, classes_num = getClassesMes(source_path)
    # """调用上面的函数，在训练集验证集和测试集文件夹下建立五类图像的文件夹"""
    # mkClassDir(source_path, train_path)
    # mkClassDir(source_path, validation_path)
    # mkClassDir(source_path, test_path)
    """
    先将一类图像的路径拿出来，将这个路径下所有这类的图片，就是800张图片的文件名做成一个列表，使用os.listdir函数，
    然后再将列表里面的所有图像名进行shuffle就是随机打乱，然后从打乱后的图像中抽7成放入训练集，2成放入验证集，1成
    放入测试集的图像名称列表
    """
    source_image_dir = [file for file in os.listdir(source_path + 'images/') if file.endswith('.JPG')]
    source_json_dir = [file for file in os.listdir(source_path + 'annotations/') if file.endswith('.json')]
    random.shuffle(source_json_dir)
    train_json_list = source_json_dir[0:int(split_ratio[0] * len(source_json_dir))]
    validation_json_list = source_json_dir[int(split_ratio[0] * len(source_json_dir)):
                                             int((split_ratio[0]+split_ratio[1]) * len(source_json_dir))]
    test_json_list = source_json_dir[int((1-split_ratio[2]) * len(source_json_dir)):]
    json_list = [train_json_list, validation_json_list, test_json_list]
    """
    找到每一个集合列表中每一张图像的原始图像位置，然后将这张图像复制到目标的路径下，一共是五类图像
    每类图像随机被分成三个去向，使用shutil库中的copy2函数进行复制，当然也可以使用move函数，但是move
    相当于移动图像，当操作结束后，原始文件夹中的图像会都跑到目标文件夹中，如果划分不正确你想重新划分
    就需要备份，不然的话很麻烦
    """
    for index, split_item in enumerate(['/train/', 'val', 'testval']):
        cur_json_list = json_list[index]
        empty_dir(source_path + 'images/' + split_item)
        empty_dir(source_path + 'annotations/' + split_item)
        for js in cur_json_list:
            origins_image_path = source_path + 'images/' + js.replace('.json', '.JPG')
            origins_json_path = source_path + 'annotations/' + js
            try:
                assert os.path.exists(origins_image_path)
            except:
                print(origins_image_path)
                continue
            new_image_path = source_path + 'images/' + split_item
            new_json_path = source_path + 'annotations/' + split_item
            copy2(origins_image_path, new_image_path)
            copy2(origins_json_path, new_json_path)

def copy_json_to(original_json_path, new_json_path):
    for root, dirs, files in os.walk(original_json_path):
        for name in files:
            if name.endswith('.json'):
                original_file_path = os.path.join(root, name)
                copy2(original_file_path, new_json_path)

def copy_img_to(original_img_path, new_img_path):
    for root, dirs, files in os.walk(original_img_path):
        for name in files:
            original_path = os.path.join(root, name)
            # if root.split('\\')[-1][:3]== 'Day':
            if name[-4:] == '.JPG':
                copy2(original_path, new_img_path)

if __name__ == '__main__':
    # 不用提前建文件夹，不然会出错
    # original_json_path = '/data/code/xcq/dataset/pv_ir/ZhengTai2DataSet/images'
    # target_json_path = '/data/code/xcq/dataset/pv_ir/ZhengTai2DataSet/annotations'
    # copy_json_to(original_json_path, target_json_path)
    # original_img_path = 'E:\\巡检数据\\第三批数据\\Infrared_Images'
    # target_img_path = 'E:\\datasets\\pv_ir\\ZhengTai2DataSet\\images'
    # copy_img_to(original_img_path, target_img_path)
    data_path = '/data/code/xcq/dataset/pv_ir/ZhengTai2DataSet/'  # train的上一级
    # source_path = data_path
    # mkTotalDir(data_path)
    divideTrainValidationTest(data_path)

