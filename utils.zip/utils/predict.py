import os
import sys
import torch
import time

cur_path = os.path.abspath(os.path.dirname(__file__))
root_path = os.path.split(cur_path)[0]
sys.path.append(root_path)

from PIL import Image
from torchvision import transforms
from segmentron.models.model_zoo import get_segmentation_model
from segmentron.config import cfg
from imageutils.prepare_seg_images import prepare_images


def load_model():
    # output folder
    # image transform
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if cfg.DATASET.NAME == 'pv_ir':
        transform = transforms.Compose([
            transforms.ToTensor()
        ])
    else:
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(cfg.DATASET.MEAN, cfg.DATASET.STD)
        ])

    model = get_segmentation_model().to(device)
    model.eval()
    return model, transform, device

def predict(img_paths, model, transform, device='cuda', sensor='h20t', batch_idx=None, time_recoder=None):
    batch_images = []
    masks = []
    temperature = []
    time_recoder['preprocess'][batch_idx] = time.time()
    for img_path in img_paths:
        # pads = (padw, padh) used for recover images and masks
        temperature_per, pre_img, pads = prepare_images(img_path, transform, sensor)
        batch_images.append(pre_img)
        temperature.append(temperature_per)
    time_recoder['preprocess'][batch_idx] = time.time() - time_recoder['preprocess'][batch_idx]
    images = torch.stack(batch_images)
    images = images.to(device=device)
    time_recoder['seg'][batch_idx] = time.time()
    with torch.no_grad():
        if cfg.MODEL.MODEL_NAME.lower() == 'unet':
            output = model(images)
        else:
            output = model(images)[0]
    time_recoder['seg'][batch_idx] = time.time() - time_recoder['seg'][batch_idx]
    images = [image[:image.shape[-2]-pads[0], :image.shape[-1]-pads[1]] for image in images.squeeze(1).cpu()]
    preds = torch.argmax(output, 1).squeeze(1).cpu().data.numpy()

    for pred in preds:
        # if sensor == 'xt2':
        #     pred[:25, :] = 0  # 25
        #     pred[475:, :] = 0  # 475
        #     pred[:, :25] = 0  # 25
        #     pred[:, 600:] = 0  # 600
        masks.append(Image.fromarray(pred.astype('uint8') * 255))
    return temperature, images, masks
